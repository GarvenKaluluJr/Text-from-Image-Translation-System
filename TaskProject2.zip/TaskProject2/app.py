from flask import Flask, render_template, request, jsonify
import pytesseract
from PIL import Image
from deep_translator import GoogleTranslator
import os

# Initializing Flask App
app = Flask(__name__)

# Configure Upload Folder
UPLOAD_FOLDER = './uploads/'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Tesseract OCR Configuration (Update Path for Your System)
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


def ocr_and_translate(image_path, target_lang='en'):
    """
    Performs OCR on an image and translates the detected text to the target language.

    Args:
        image_path (str): Path to the image file
        target_lang (str): Target language code (default: 'en' for English)

    Returns:
        tuple: (original_text, translated_text)
    """
    try:
        # Open the image
        img = Image.open(image_path)

        # Perform OCR
        original_text = pytesseract.image_to_string(img)

        if not original_text.strip():
            return None, "No text detected in the image."

        # Initialize translator and translate
        translator = GoogleTranslator(source='auto', target=target_lang)
        translated_text = translator.translate(original_text)

        return original_text, translated_text

    except Exception as e:
        return None, f"Error processing image: {str(e)}"


@app.route('/')
def index():
    """Serve the HTML page."""
    return render_template('text_translating_system.html')


@app.route('/upload', methods=['POST'])
def upload_and_process_image():
    """Handle image upload and text processing."""
    if 'file' not in request.files:
        return jsonify(success=False, error="No file uploaded.")

    file = request.files['file']
    if file and file.filename != '':
        # Save the file to the uploads folder
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)

        # Get the target language
        target_lang = request.form.get('target_lang', 'en')

        # Perform OCR and translation
        original_text, translated_text = ocr_and_translate(file_path, target_lang)

        # If OCR fails, return error
        if not original_text:
            return jsonify(success=False, error=translated_text)

        # Return the extracted and translated text
        return jsonify(success=True, original=original_text, translated=translated_text)

    return jsonify(success=False, error="Invalid file.")


if __name__ == '__main__':
    app.run(debug=True)
